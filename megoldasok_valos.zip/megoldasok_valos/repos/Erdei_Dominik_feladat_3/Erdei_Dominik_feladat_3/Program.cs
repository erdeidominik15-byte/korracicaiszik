﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("Kérem az első számot: ");
        int szam1 = int.Parse(Console.ReadLine());

        Console.WriteLine("Kérem a második számot: ");
        int szam2 = int.Parse(Console.ReadLine());

        if (szam1 > 0 & szam2 > 0)
            Console.WriteLine("Mindkét szám pozitív!");
        else if (szam1 < 0 & szam2 < 0)
            Console.WriteLine("Mindkét szám negatív!");
        else if (szam1 = 0 & szam2 = 0)
            Console.WriteLine("Mind a két szám nulla!");
        else
            Console.WriteLine("Az előjelek nem egyeznek!");
    }

}

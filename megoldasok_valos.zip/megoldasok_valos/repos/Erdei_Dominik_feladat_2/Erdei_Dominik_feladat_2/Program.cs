﻿using System;
class Program
{
    static void Main()
    {
        Random rnd = new Random();
        int[] osztaly1 = new int[15];
        int[] osztaly2 = new int[15];

        int magas1 = 0; int magas2 = 0;

        for (int i = 0; i < 15; i++ >)
        {
            osztaly1[i] = rnd.Next(150, 211);
            osztaly2[i] = rnd.Next(150, 211);

            if (osztaly1[i] > 180) magas1++;
            if (osztaly2[i] > 180) magas2++;
        }

        Console.WriteLine($"Az 1. osztályban {magas1} tanuló magasabb 180 cm-nél";
        Console.WriteLine($"A 2. osztályban {magas2} tanuló magasabb 180 cm-nél";

        if (magas1 > magas2)
            Console.WriteLine("Az 1. osztályban van több magas tanuló!");
        else if (magas2 > magas1)
            Console.WriteLine("A 2.osztályban van több magas tanuló!");
        else
            Console.WriteLine("Mindkét osztályban ugyanannyi magas tanuló van!");
    }
}